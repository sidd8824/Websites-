// Geometry for the "robot hauls a cloth up the screen" entrance.
// Everything is in a 1200 x 100 viewBox (x across the screen, y down the entrance runway).
// The cloth is pinched at the middle (where the robot holds it) and drapes down to both
// sides; at the sides it is anchored to the bottom of the runway (y = 100).

export const VB_W = 1200;
export const VB_H = 100;
export const SAG = 62; // how far the edge falls away from the held point
export const FALL = 250; // width of the drape (smaller = pointier tent)
const BOTTOM = 100.6;

/** Y (in viewBox units) of the held point for scroll progress p in 0..1. */
export function peakY(p: number): number {
  return 100 - (100 + SAG) * Math.min(1, Math.max(0, p));
}

export type Cloth = {
  fill: string; // closed path for the cloth body
  edge: string; // open path along the top edge (for the highlight line)
  folds: { points: string; dark: boolean }[]; // fan of folds radiating from the held point
};

function edgeY(x: number, P: number, phase: number, rip: number, lag: number): number {
  const d = Math.abs(x - VB_W / 2);
  const drape = SAG * (1 - Math.exp(-d / FALL));
  // gentle ripples that grow away from the hands and travel with the scroll
  const ripple = rip * Math.sin(x / 70 - phase * 0.9) * (1 - Math.exp(-(d * d) / 22000));
  return Math.min(BOTTOM, P + lag + drape + ripple);
}

/** Build the cloth for progress p. `phase` is the scroll-driven walk phase (radians). */
export function buildCloth(p: number, phase: number, rip = 2.4, lag = 0): Cloth {
  const P = peakY(p);
  const pts: [number, number][] = [];
  for (let x = -40; x <= VB_W + 40; x += 20) pts.push([x, edgeY(x, P, phase, rip, lag)]);
  const edge = 'M' + pts.map(([x, y]) => `${x.toFixed(1)} ${y.toFixed(2)}`).join(' L');
  const fill = `${edge} L${VB_W + 40} 260 L-40 260 Z`;

  // fold wedges fanning out from the hands, swaying a little with the walk
  const folds: Cloth['folds'] = [];
  const n = 16;
  const apexY = P + lag + 1.5;
  for (let i = 0; i < n; i++) {
    const t = i / (n - 1);
    const baseX = -900 + t * (VB_W + 1800);
    const sway = Math.sin(phase * 0.5 + i * 1.3) * 14;
    const w = 55 + 25 * Math.sin(i * 2.1);
    const x1 = baseX + sway;
    const x2 = x1 + w;
    folds.push({
      points: `${VB_W / 2} ${apexY.toFixed(2)} ${x1.toFixed(1)} 300 ${x2.toFixed(1)} 300`,
      dark: i % 2 === 0,
    });
  }
  return { fill, edge, folds };
}
