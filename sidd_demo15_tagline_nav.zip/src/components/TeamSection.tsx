import { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Github, Linkedin, Mail } from 'lucide-react';
import { TEAM_MEMBERS, TeamMember, VERTICALS } from '../data/club';
import './TeamSection.css';

// "THE CREW!": a fanned hand of playful trading cards (see the Concept Capers reference).
// Front = photo + name + one short line. Click a card to flip it (role, verticals, links).
// Arrows, swipe, or the keyboard arrow keys deal the next card in.

const NAVY = '#14163F';
const DISPLAY = "'Bricolage Grotesque','Archivo Black',-apple-system,sans-serif";
const MONO = "'JetBrains Mono',monospace";

const SKINS = ['#F6D3B3', '#E8B98F', '#C68B5E', '#8D5A3B', '#FBE0C8'];
const HAIRS = ['#2A1B3D', '#4A2C1A', '#171717', '#7A3B1E', '#C9A227'];

// Cartoon fallback until a real photo is set via `photoUrl` in data/club.ts
function CartoonAvatar({ member, idx }: { member: TeamMember; idx: number }) {
  const skin = SKINS[idx % SKINS.length];
  const hair = HAIRS[(idx * 2 + 1) % HAIRS.length];
  const shirt = VERTICALS[member.verticals[0]]?.color ?? '#8B5CF6';
  const glasses = member.verticals.includes('B/Algo');
  const style = idx % 4;

  return (
    <svg viewBox="0 0 200 200" width="100%" height="100%" aria-hidden="true" style={{ display: 'block' }}>
      {/* shoulders */}
      <path d="M14 200 C14 152 56 134 100 134 C144 134 186 152 186 200 Z" fill={shirt} stroke={NAVY} strokeWidth="4" strokeLinejoin="round" />
      <path d="M82 136 L100 160 L118 136" fill="none" stroke={NAVY} strokeWidth="4" strokeLinejoin="round" strokeLinecap="round" />
      {/* neck */}
      <rect x="86" y="108" width="28" height="32" rx="8" fill={skin} stroke={NAVY} strokeWidth="4" />
      {/* hair behind head */}
      {style === 2 && (
        <g fill={hair} stroke={NAVY} strokeWidth="4">
          <circle cx="62" cy="62" r="22" />
          <circle cx="138" cy="62" r="22" />
          <circle cx="100" cy="46" r="26" />
        </g>
      )}
      {style === 3 && <circle cx="100" cy="30" r="17" fill={hair} stroke={NAVY} strokeWidth="4" />}
      {/* ears + head */}
      <circle cx="61" cy="88" r="8" fill={skin} stroke={NAVY} strokeWidth="4" />
      <circle cx="139" cy="88" r="8" fill={skin} stroke={NAVY} strokeWidth="4" />
      <ellipse cx="100" cy="84" rx="40" ry="44" fill={skin} stroke={NAVY} strokeWidth="4" />
      {/* hair on top */}
      {style === 0 && <path d="M58 76 C54 36 146 34 142 76 C132 56 70 54 58 76 Z" fill={hair} stroke={NAVY} strokeWidth="4" strokeLinejoin="round" />}
      {style === 1 && <path d="M58 80 C50 30 150 28 142 78 C130 62 104 52 84 56 C72 60 62 68 58 80 Z" fill={hair} stroke={NAVY} strokeWidth="4" strokeLinejoin="round" />}
      {style === 2 && <path d="M62 70 C70 50 130 50 138 70 C124 62 76 62 62 70 Z" fill={hair} stroke={NAVY} strokeWidth="4" strokeLinejoin="round" />}
      {style === 3 && <path d="M58 76 C56 38 144 38 142 76 C128 58 72 58 58 76 Z" fill={hair} stroke={NAVY} strokeWidth="4" strokeLinejoin="round" />}
      {/* face */}
      {glasses ? (
        <g stroke={NAVY} strokeWidth="4">
          <circle cx="82" cy="88" r="12" fill="#fff" />
          <circle cx="118" cy="88" r="12" fill="#fff" />
          <line x1="94" y1="88" x2="106" y2="88" />
          <circle cx="83" cy="89" r="3.5" fill={NAVY} stroke="none" />
          <circle cx="119" cy="89" r="3.5" fill={NAVY} stroke="none" />
        </g>
      ) : (
        <g fill={NAVY}>
          <ellipse cx="82" cy="89" rx="5" ry="6" />
          <ellipse cx="118" cy="89" rx="5" ry="6" />
          <circle cx="84" cy="87" r="1.8" fill="#fff" />
          <circle cx="120" cy="87" r="1.8" fill="#fff" />
        </g>
      )}
      <path d="M84 108 Q100 124 116 108" fill="none" stroke={NAVY} strokeWidth="4" strokeLinecap="round" />
      <circle cx="70" cy="104" r="6" fill="#F0997B" opacity="0.55" />
      <circle cx="130" cy="104" r="6" fill="#F0997B" opacity="0.55" />
    </svg>
  );
}

function useViewportWidth() {
  const [w, setW] = useState(() => (typeof window === 'undefined' ? 1200 : window.innerWidth));
  useEffect(() => {
    const onResize = () => setW(window.innerWidth);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  return w;
}

export default function TeamSection() {
  const members = TEAM_MEMBERS;
  const total = members.length;
  const [active, setActive] = useState(Math.min(2, total - 1));
  const [flipped, setFlipped] = useState<Record<string, boolean>>({});
  const width = useViewportWidth();

  const compact = width < 700;
  const scale = compact ? 0.78 : 0.88;
  const step = compact ? 140 : 232; // horizontal distance between neighbouring cards
  const reach = compact ? 1 : 2; // how many cards are visible on each side

  const dragStart = useRef<number | null>(null);
  const didDrag = useRef(false);

  const go = (dir: number) => {
    setFlipped({});
    setActive((a) => (a + dir + total) % total);
  };

  const toggleFlip = (id: string) => {
    if (didDrag.current) return;
    setFlipped((f) => ({ ...f, [id]: !f[id] }));
  };

  const offsets = useMemo(
    () =>
      members.map((_, i) => {
        let d = (i - active + total) % total;
        if (d > total / 2) d -= total;
        return d;
      }),
    [members, active, total]
  );

  return (
    <section
      id="team"
      className="relative min-h-screen py-28 px-3 sm:px-6 flex flex-col justify-center"
      aria-label="Team Section"
    >
      <div className="crew-panel">
        {/* Title banner sitting on the panel's top edge */}
        <div className="crew-banner">
          <h2 style={{ fontFamily: DISPLAY, fontWeight: 900, letterSpacing: '-0.02em', lineHeight: 1, fontSize: compact ? 34 : 56, margin: 0 }}>
            THE CREW!
          </h2>
        </div>

        {/* Card stage */}
        <div
          className="crew-stage"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'ArrowRight') go(1);
            if (e.key === 'ArrowLeft') go(-1);
          }}
          onPointerDown={(e) => {
            dragStart.current = e.clientX;
            didDrag.current = false;
          }}
          onPointerUp={(e) => {
            if (dragStart.current === null) return;
            const dx = e.clientX - dragStart.current;
            dragStart.current = null;
            if (Math.abs(dx) > 40) {
              didDrag.current = true;
              go(dx < 0 ? 1 : -1);
              window.setTimeout(() => (didDrag.current = false), 50);
            }
          }}
        >
          <button className="crew-arrow" style={{ left: compact ? -4 : -40 }} onClick={() => go(-1)} aria-label="Previous member">
            <ChevronLeft size={24} />
          </button>
          <button className="crew-arrow" style={{ right: compact ? -4 : -40 }} onClick={() => go(1)} aria-label="Next member">
            <ChevronRight size={24} />
          </button>

          {members.map((m, i) => {
            const off = offsets[i];
            const abs = Math.abs(off);
            const visible = abs <= reach;
            const x = Math.max(-reach - 1, Math.min(reach + 1, off)) * step * scale;
            const y = (abs * abs * 9 + (abs === 0 ? -6 : 0)) * scale;
            const rot = Math.max(-reach - 1, Math.min(reach + 1, off)) * (compact ? 9 : 8);
            const isFlipped = !!flipped[m.id];
            const vColor = VERTICALS[m.verticals[0]]?.color ?? '#8B5CF6';
            const pastel = `color-mix(in srgb, ${m.avatarColor} 42%, white)`;

            return (
              <div
                key={m.id}
                className="crew-slot"
                data-cursor="flip"
                style={{
                  transform: `translate(${x}px, ${y}px) rotate(${rot}deg) scale(${scale})`,
                  opacity: visible ? 1 : 0,
                  pointerEvents: visible ? 'auto' : 'none',
                  zIndex: 20 - abs,
                }}
                aria-hidden={!visible}
              >
                <div className="crew-lift" onClick={() => toggleFlip(m.id)} role="button" aria-label={`${m.name}: flip card`}>
                  <div className={`crew-flip ${isFlipped ? 'is-flipped' : ''}`}>
                    {/* ============ FRONT ============ */}
                    <div className="crew-face crew-front">
                      {/* coloured art panel */}
                      <div
                        style={{
                          position: 'absolute', left: 7, right: 7, top: 7, height: 236,
                          borderRadius: 10, overflow: 'hidden', background: pastel, border: `2px solid ${NAVY}`,
                        }}
                      >
                        <div style={{ position: 'absolute', left: '50%', top: 26, width: 176, height: 176, marginLeft: -88, borderRadius: '50%', background: 'rgba(255,255,255,0.45)' }} />
                        <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 214 }}>
                          {m.photoUrl ? (
                            <img src={m.photoUrl} alt={m.name} loading="lazy" draggable={false} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                          ) : (
                            <CartoonAvatar member={m} idx={i} />
                          )}
                        </div>
                      </div>

                      {/* number badge */}
                      <div
                        style={{
                          position: 'absolute', left: 12, top: 12, width: 36, height: 36, borderRadius: '50%',
                          background: vColor, color: '#fff', border: '3px solid #fff', boxShadow: `0 0 0 2px ${NAVY}`,
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          fontFamily: DISPLAY, fontWeight: 900, fontSize: 16,
                        }}
                      >
                        {i + 1}
                      </div>

                      {m.isLead && (
                        <div
                          style={{
                            position: 'absolute', right: 12, top: 14, padding: '2px 9px', borderRadius: 99,
                            background: '#FDE047', color: NAVY, border: `2px solid ${NAVY}`,
                            fontFamily: DISPLAY, fontWeight: 900, fontSize: 10, letterSpacing: 1,
                          }}
                        >
                          LEAD
                        </div>
                      )}

                      {/* slanted name ribbon */}
                      <div
                        style={{
                          position: 'absolute', left: -6, right: -6, top: 214, height: 36,
                          background: NAVY, border: '2px solid #fff', outline: `2px solid ${NAVY}`,
                          transform: 'rotate(-4deg)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                          padding: '0 10px',
                        }}
                      >
                        <span style={{ fontFamily: DISPLAY, fontWeight: 900, fontSize: 17, color: '#fff', textTransform: 'uppercase', letterSpacing: '0.02em', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                          {m.name}
                        </span>
                      </div>

                      {/* little description box */}
                      <div
                        style={{
                          position: 'absolute', left: 14, right: 14, bottom: 11, height: 62,
                          background: '#fff', border: `2px solid ${NAVY}`, borderRadius: 8,
                          padding: '6px 9px', display: 'flex', alignItems: 'center', justifyContent: 'center',
                        }}
                      >
                        <p className="crew-clamp" style={{ margin: 0, textAlign: 'center', fontSize: 11, lineHeight: 1.3, color: NAVY, fontFamily: "'Inter',-apple-system,sans-serif" }}>
                          {m.description}
                        </p>
                      </div>
                    </div>

                    {/* ============ BACK ============ */}
                    <div className="crew-face crew-back">
                      <div style={{ position: 'absolute', inset: 8, border: '2px dashed rgba(255,255,255,0.35)', borderRadius: 10, padding: '14px 12px 10px', display: 'flex', flexDirection: 'column' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          <div style={{ flex: 'none', width: 32, height: 32, borderRadius: '50%', background: vColor, border: '3px solid #fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: DISPLAY, fontWeight: 900, fontSize: 14 }}>
                            {i + 1}
                          </div>
                          <div style={{ minWidth: 0 }}>
                            <div style={{ fontFamily: DISPLAY, fontWeight: 900, fontSize: 15, textTransform: 'uppercase', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{m.name}</div>
                            <div style={{ fontFamily: MONO, fontSize: 9.5, color: '#C4B5FD', lineHeight: 1.25 }}>{m.role}</div>
                          </div>
                        </div>

                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, marginTop: 12 }}>
                          {m.verticals.map((v) => (
                            <span key={v} style={{ padding: '2px 8px', borderRadius: 5, background: VERTICALS[v].color, border: '2px solid #fff', fontFamily: MONO, fontWeight: 800, fontSize: 9.5 }}>
                              {v}
                            </span>
                          ))}
                        </div>

                        <p style={{ margin: '12px 0 0', fontSize: 11, lineHeight: 1.35, color: '#E6EDF7', fontFamily: "'Inter',-apple-system,sans-serif" }}>
                          <strong style={{ color: '#67E8F9' }}>Builds: </strong>
                          {m.whatIBuild}
                        </p>

                        <div style={{ margin: '10px 0 0', padding: '7px 9px', borderRadius: 8, background: '#fff', color: NAVY, fontSize: 10.5, lineHeight: 1.3, fontFamily: "'Inter',-apple-system,sans-serif" }}>
                          <strong>Fun fact: </strong>
                          {m.funFact}
                        </div>

                        <div style={{ marginTop: 'auto', display: 'flex', justifyContent: 'center', gap: 12 }}>
                          <a className="crew-social" href={m.github} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} title="GitHub"><Github size={16} /></a>
                          <a className="crew-social" href={m.linkedin} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} title="LinkedIn"><Linkedin size={16} /></a>
                          <a className="crew-social" href={`mailto:${m.email}`} onClick={(e) => e.stopPropagation()} title="Email"><Mail size={16} /></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Caption label under the deck */}
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: 4 }}>
          <div
            style={{
              background: '#fff', color: NAVY, border: `2px solid ${NAVY}`, padding: '8px 22px',
              fontFamily: DISPLAY, fontWeight: 700, fontSize: compact ? 15 : 19, transform: 'rotate(-1deg)',
              boxShadow: `3px 3px 0 ${NAVY}`,
            }}
          >
            A card deck of B/Stack builders · click a card to flip it
          </div>
        </div>
      </div>
    </section>
  );
}
