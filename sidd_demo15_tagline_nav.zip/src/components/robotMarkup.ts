// A small hauler robot (front view), arms up gripping the edge of the cloth.
// Parts carry data-* hooks so the walk cycle can animate them from the scroll position.
export const ROBOT_W = 120;
export const ROBOT_H = 176;
export const ROBOT_HAND_Y = 7; // y of the grip points inside the viewBox

export const ROBOT_SVG = `
<svg viewBox="0 0 ${ROBOT_W} ${ROBOT_H}" width="100%" height="100%" style="overflow:visible" aria-hidden="true">
  <defs>
    <linearGradient id="botMetal" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#F1F5F9"/><stop offset="1" stop-color="#94A3B8"/>
    </linearGradient>
    <filter id="botGlow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="2.5"/></filter>
  </defs>
  <ellipse cx="60" cy="172" rx="38" ry="5" fill="#000" opacity="0.28"/>
  <!-- legs: lift alternately -->
  <g data-leg="l">
    <rect x="40" y="116" width="15" height="40" rx="6" fill="#94A3B8"/>
    <rect x="34" y="150" width="27" height="15" rx="7.5" fill="#334155"/>
  </g>
  <g data-leg="r">
    <rect x="65" y="116" width="15" height="40" rx="6" fill="#94A3B8"/>
    <rect x="59" y="150" width="27" height="15" rx="7.5" fill="#334155"/>
  </g>
  <g data-body>
    <!-- arms up to the cloth -->
    <path d="M37 70 Q10 46 46 9" stroke="#64748B" stroke-width="9" stroke-linecap="round" fill="none"/>
    <path d="M83 70 Q110 46 74 9" stroke="#64748B" stroke-width="9" stroke-linecap="round" fill="none"/>
    <!-- torso -->
    <rect x="34" y="58" width="52" height="62" rx="14" fill="url(#botMetal)"/>
    <rect x="44" y="69" width="32" height="24" rx="6" fill="#1E293B"/>
    <circle cx="60" cy="81" r="9" fill="#F97316" opacity="0.7" filter="url(#botGlow)" data-chest-glow/>
    <circle cx="60" cy="81" r="5.5" fill="#FDBA74"/>
    <rect x="34" y="106" width="52" height="8" rx="4" fill="#64748B"/>
    <!-- head -->
    <g data-head>
      <rect x="54" y="50" width="12" height="9" rx="3" fill="#64748B"/>
      <rect x="36" y="16" width="48" height="36" rx="13" fill="url(#botMetal)"/>
      <rect x="42" y="24" width="36" height="20" rx="9" fill="#0F172A"/>
      <circle cx="52" cy="34" r="4.5" fill="#22D3EE" opacity="0.8" filter="url(#botGlow)"/>
      <circle cx="68" cy="34" r="4.5" fill="#22D3EE" opacity="0.8" filter="url(#botGlow)"/>
      <circle cx="52" cy="34" r="3.2" fill="#A5F3FC"/>
      <circle cx="68" cy="34" r="3.2" fill="#A5F3FC"/>
      <rect x="31" y="28" width="5" height="12" rx="2.5" fill="#64748B"/>
      <rect x="84" y="28" width="5" height="12" rx="2.5" fill="#64748B"/>
    </g>
    <!-- grip clamps -->
    <circle cx="46" cy="${ROBOT_HAND_Y}" r="7.5" fill="#F97316"/>
    <circle cx="74" cy="${ROBOT_HAND_Y}" r="7.5" fill="#F97316"/>
    <circle cx="46" cy="${ROBOT_HAND_Y}" r="3" fill="#7C2D12"/>
    <circle cx="74" cy="${ROBOT_HAND_Y}" r="3" fill="#7C2D12"/>
  </g>
</svg>`;

/** March in place: legs lift alternately, body bobs, head tilts. `phase` comes from scroll distance. */
export function poseRobot(root: Element, phase: number) {
  const s = Math.sin(phase);
  const lift = 11;
  const l = root.querySelector<SVGGElement>('[data-leg="l"]');
  const r = root.querySelector<SVGGElement>('[data-leg="r"]');
  const body = root.querySelector<SVGGElement>('[data-body]');
  const head = root.querySelector<SVGGElement>('[data-head]');
  const glow = root.querySelector<SVGElement>('[data-chest-glow]');
  l?.setAttribute('transform', `translate(0 ${(-Math.max(0, s) * lift).toFixed(2)})`);
  r?.setAttribute('transform', `translate(0 ${(-Math.max(0, -s) * lift).toFixed(2)})`);
  body?.setAttribute('transform', `translate(0 ${(-Math.abs(s) * 2.5).toFixed(2)})`);
  head?.setAttribute('transform', `rotate(${(s * 4).toFixed(2)} 60 52)`);
  glow?.setAttribute('opacity', (0.55 + 0.3 * Math.abs(Math.sin(phase * 0.5))).toFixed(2));
}
