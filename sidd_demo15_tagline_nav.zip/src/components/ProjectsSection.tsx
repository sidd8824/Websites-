import { useState, useRef, useEffect } from 'react';
import { PROJECTS, Project } from '../data/club';
import { glowStyle, hexToRgb } from '../utils/glow';
import HangingMascot from './HangingMascot';
import { ExternalLink, X, Github, Sparkles, Code2, Bot, Cloud, Award, Radio } from 'lucide-react';

interface ProjectsSectionProps {
  scrollProgress: number;
}

const SERIF = { fontFamily: 'Georgia, "Times New Roman", serif' } as const;
const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const smooth = (t: number) => t * t * (3 - 2 * t);
// Each project has its own frame shape, like a magazine layout (portrait / landscape mix)
const RATIOS = [4 / 5, 4 / 3, 3 / 4, 16 / 10, 1];

/** "Project name 01: RoboStack Rover" -> { first: "RoboStack", rest: "Rover" } */
function splitTitle(title: string) {
  const name = title.includes(':') ? title.split(':').slice(1).join(':').trim() : title;
  const [first, ...rest] = name.split(' ');
  return { first, rest: rest.join(' ') };
}


/** Description card with a hand-drawn "scribble out" + 3D tumble when it switches. */
function DescPanel({
  proj, index, d, right, isDesktop, onOpen,
}: { proj: Project; index: number; d: number; right: boolean; isDesktop: boolean; onOpen: () => void }) {
  const enter = smooth(clamp((0.1 - d) / 0.22));       // d 0.1 -> -0.12
  const exitP = clamp((-0.5 - d) / 0.28);               // d -0.5 -> -0.78
  const scribble = clamp(exitP * 1.7);                  // crossing-out lines draw first
  const fade = smooth(clamp((exitP - 0.35) / 0.65));    // then the card tumbles away
  const opacity = enter * (1 - fade);
  if (opacity <= 0.01) return null;
  const color = proj.verticalColor;
  const lines = proj.descriptionLines;
  const dir = right ? 1 : -1;
  const tumble = (1 - enter) * -65 + fade * 75;         // rotateX: falls in from below, flips up and away
  const spin = (1 - enter) * 14 * dir + fade * -10 * dir;

  return (
    <div
      className="absolute z-20"
      style={{
        opacity,
        pointerEvents: opacity > 0.6 ? 'auto' : 'none',
        perspective: 900,
        ...(isDesktop
          ? { top: '50%', [right ? 'left' : 'right']: '4vw', width: '22vw', maxWidth: 360, transform: 'translateY(-46%)' }
          : { left: '5vw', right: '5vw', bottom: '3vh' }),
      }}
    >
      <div
        className="relative"
        style={{
          transformOrigin: '50% 100%',
          transform: `rotateX(${tumble}deg) rotateZ(${spin}deg) translateY(${(1 - enter) * 40 - fade * 30}px)`,
          filter: fade > 0 ? `blur(${fade * 5}px)` : undefined,
        }}
      >
        <div className={`glass rounded-2xl overflow-hidden ${isDesktop ? 'p-5 sm:p-6' : 'p-4'}`} style={glowStyle(color)}>
          {/* giant outlined index number */}
          <div
            className="absolute -top-3 right-2 font-display font-black leading-none pointer-events-none select-none"
            style={{ fontSize: isDesktop ? 88 : 56, color: 'transparent', WebkitTextStroke: `1.5px rgb(${hexToRgb(color)} / 0.55)` }}
          >
            {String(index + 1).padStart(2, '0')}
          </div>
          <div className="relative flex items-center gap-2 font-mono text-[10px] tracking-[0.2em] uppercase">
            <span className="px-2 py-0.5 rounded glass-chip" style={{ color }}>{proj.vertical}</span>
            <span className="text-[#A7A3C7]">{proj.badge}</span>
          </div>
          <p className={`relative text-[#E6EDF7] leading-snug ${isDesktop ? 'mt-4 text-base sm:text-[17px]' : 'mt-3 text-sm pr-12'}`}>{lines[0]}</p>
          {isDesktop && (
            <dl className="relative mt-4 space-y-2.5 text-xs leading-relaxed text-[#A7A3C7]">
              <div><dt className="font-mono uppercase tracking-widest text-[10px] text-[#E6EDF7]">Build</dt><dd>{lines[1]}</dd></div>
              <div><dt className="font-mono uppercase tracking-widest text-[10px] text-[#5DCAA5]">Status</dt><dd>{lines[3]}</dd></div>
            </dl>
          )}
          <div className={`relative flex flex-wrap gap-1.5 ${isDesktop ? 'mt-4' : 'mt-3'}`}>
            {proj.tags.slice(0, isDesktop ? 5 : 3).map((t) => (
              <span key={t} className="px-2 py-0.5 rounded-md font-mono text-[10px] glass-chip">{t}</span>
            ))}
          </div>
          <button onClick={onOpen} className={`relative inline-flex items-center gap-1.5 font-mono text-[11px] font-bold text-[#67E8F9] hover:text-white cursor-pointer ${isDesktop ? 'mt-5' : 'mt-3'}`}>
            Open project <span aria-hidden>↗</span>
          </button>

          {/* doodle: scribble-out lines that draw across the card as it leaves */}
          <svg className="wobble-doodle absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 300 300" preserveAspectRatio="none" fill="none">
            {['M8 40 L292 70 L10 110 L290 150', 'M12 170 L288 200 L14 240 L286 270'].map((path, k) => (
              <path
                key={k}
                d={path}
                stroke={color}
                strokeWidth="5"
                strokeLinecap="round"
                strokeLinejoin="round"
                pathLength={1}
                strokeDasharray={1}
                strokeDashoffset={1 - clamp(scribble * 2 - k)}
                opacity={scribble > 0 ? 0.9 : 0}
              />
            ))}
          </svg>
        </div>

        {/* doodles around the card: pop in on arrival */}
        <svg
          className="wobble-doodle absolute -top-7 -left-6 w-14 h-14 pointer-events-none"
          viewBox="0 0 60 60" fill="none"
          style={{ transform: `scale(${enter}) rotate(${(1 - enter) * -40}deg)`, color }}
        >
          <path d="M30 6 L35 24 L54 30 L35 36 L30 54 L25 36 L6 30 L25 24 Z" stroke="currentColor" strokeWidth="2.5" strokeLinejoin="round" />
        </svg>
        <svg
          className="wobble-doodle absolute -bottom-8 -right-5 w-24 h-10 pointer-events-none text-[#67E8F9]"
          viewBox="0 0 100 40" fill="none"
          style={{ opacity: enter }}
        >
          <path
            d="M4 28 Q 22 4, 40 22 T 76 18 M 66 8 L 78 18 L 64 28"
            stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
            pathLength={1} strokeDasharray={1} strokeDashoffset={1 - enter}
          />
        </svg>
      </div>
    </div>
  );
}

export default function ProjectsSection(_props: ProjectsSectionProps) {
  const [activeFilter, setActiveFilter] = useState<string>('ALL');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [view, setView] = useState<'reel' | 'grid'>('reel');
  const [p, setP] = useState(0); // 0..1 progress through the pinned reel
  const sectionRef = useRef<HTMLElement>(null);
  const [isDesktop, setIsDesktop] = useState(true);
  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    const on = () => setIsDesktop(mq.matches);
    on();
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, []);

  const filterTabs = ['ALL', 'B/Algo', 'B/Uild', 'B/Hack', 'B/Dev'];
  const projects = activeFilter === 'ALL' ? PROJECTS : PROJECTS.filter((x) => x.vertical === activeFilter);
  const n = projects.length;

  // Respect reduced motion: skip the pinned reel and show the grid.
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) setView('grid');
  }, []);

  // Scroll progress through the pinned section
  useEffect(() => {
    if (view !== 'reel') return;
    let raf = 0;
    const update = () => {
      raf = 0;
      const el = sectionRef.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const travel = el.offsetHeight - window.innerHeight;
      setP(travel > 0 ? clamp(-r.top / travel) : 0);
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [view, n]);

  // Render animated procedural SVG illustration per project
  const renderIllustration = (type: Project['illustrationSvg'], color: string) => {
    switch (type) {
      case 'rover':
        return (
          <svg className="w-full h-full text-[#E6EDF7]" viewBox="0 0 160 120" fill="none">
            {/* Rover Chassis */}
            <rect x="35" y="45" width="90" height="35" rx="6" fill="#0B0A16" />
            <rect x="45" y="32" width="40" height="15" rx="3" fill="#67E8F9" />
            {/* Spinning wheels */}
            <circle cx="45" cy="85" r="14" fill="#0B1226" stroke="#E6EDF7" strokeWidth="3" />
            <circle cx="80" cy="85" r="14" fill="#0B1226" stroke="#E6EDF7" strokeWidth="3" />
            <circle cx="115" cy="85" r="14" fill="#0B1226" stroke="#E6EDF7" strokeWidth="3" />
            {/* Antenna with radio waves */}
            <line x1="100" y1="45" x2="115" y2="20" stroke="#1D9E75" strokeWidth="3" strokeLinecap="round" />
            <circle cx="115" cy="20" r="4" fill="#67E8F9" />
            <path d="M 120 12 A 12 12 0 0 1 126 24" stroke="#67E8F9" strokeWidth="2" strokeLinecap="round" />
          </svg>
        );
      case 'code':
        return (
          <svg className="w-full h-full text-[#E6EDF7]" viewBox="0 0 160 120" fill="none">
            {/* Terminal Window */}
            <rect x="25" y="20" width="110" height="75" rx="8" fill="#0B0A16" />
            <circle cx="40" cy="32" r="3.5" fill="#F0997B" />
            <circle cx="50" cy="32" r="3.5" fill="#67E8F9" />
            <circle cx="60" cy="32" r="3.5" fill="#5DCAA5" />
            {/* Code lines */}
            <line x1="38" y1="50" x2="75" y2="50" stroke="#8B5CF6" strokeWidth="4" strokeLinecap="round" />
            <line x1="82" y1="50" x2="110" y2="50" stroke="#E6EDF7" strokeWidth="4" strokeLinecap="round" />
            <line x1="48" y1="64" x2="95" y2="64" stroke="#67E8F9" strokeWidth="4" strokeLinecap="round" />
            <line x1="48" y1="78" x2="80" y2="78" stroke="#8B5CF6" strokeWidth="4" strokeLinecap="round" />
          </svg>
        );
      case 'cloud':
        return (
          <svg className="w-full h-full text-[#E6EDF7]" viewBox="0 0 160 120" fill="none">
            {/* P2P Cloud & Nodes */}
            <path
              d="M 50 70 A 20 20 0 0 1 70 45 A 25 25 0 0 1 115 50 A 18 18 0 0 1 120 70 Z"
              fill="#378ADD"
            />
            <circle cx="45" cy="80" r="7" fill="#0B0A16" stroke="#67E8F9" strokeWidth="2" />
            <circle cx="80" cy="88" r="7" fill="#0B0A16" stroke="#67E8F9" strokeWidth="2" />
            <circle cx="115" cy="80" r="7" fill="#0B0A16" stroke="#67E8F9" strokeWidth="2" />
            <line x1="45" y1="80" x2="80" y2="88" stroke="#0B0A16" strokeWidth="2" strokeDasharray="3 3" />
            <line x1="80" y1="88" x2="115" y2="80" stroke="#0B0A16" strokeWidth="2" strokeDasharray="3 3" />
          </svg>
        );
      case 'trophy':
        return (
          <svg className="w-full h-full text-[#E6EDF7]" viewBox="0 0 160 120" fill="none">
            {/* Hackathon Trophy */}
            <path d="M 55 30 L 105 30 L 95 65 A 15 15 0 0 1 65 65 Z" fill="#D85A30" />
            <path d="M 55 35 C 40 35 40 55 58 55" stroke="#0B0A16" strokeWidth="3" fill="none" />
            <path d="M 105 35 C 120 35 120 55 102 55" stroke="#0B0A16" strokeWidth="3" fill="none" />
            <rect x="75" y="65" width="10" height="20" fill="#0B0A16" />
            <rect x="60" y="85" width="40" height="12" rx="3" fill="#0B0A16" />
            <circle cx="80" cy="46" r="6" fill="#67E8F9" />
          </svg>
        );
      case 'iot':
        return (
          <svg className="w-full h-full text-[#E6EDF7]" viewBox="0 0 160 120" fill="none">
            {/* IoT Beacon & Solar */}
            <rect x="60" y="45" width="40" height="45" rx="6" fill="#1D9E75" />
            <polygon points="50,45 80,25 110,45" fill="#67E8F9" />
            <circle cx="80" cy="65" r="8" fill="#0B0A16" />
            {/* Signal waves */}
            <path d="M 95 55 A 16 16 0 0 1 105 75" stroke="#1D9E75" strokeWidth="2.5" strokeLinecap="round" />
            <path d="M 102 48 A 24 24 0 0 1 114 82" stroke="#1D9E75" strokeWidth="2.5" strokeLinecap="round" />
          </svg>
        );
      default:
        return null;
    }
  };


  // pos: -1 = intro statement, 0..n-1 = project index (continuous while scrolling)
  const pos = p * (n + 0.5) - 1;
  const activeIdx = clamp(Math.round(pos), 0, Math.max(0, n - 1));
  const introD = (pos + 1) / 0.45; // 0 at top -> 1 when the intro has gone

  const filters = (
    <div className="flex flex-wrap items-center gap-2">
      {filterTabs.map((tab) => (
        <button
          key={tab}
          onClick={() => setActiveFilter(tab)}
          className={`px-3.5 py-1 rounded-full text-[11px] font-mono transition-all cursor-pointer ${
            activeFilter === tab
              ? 'bg-[#67E8F9]/20 text-[#67E8F9] border border-[#67E8F9]/60 shadow-[0_0_18px_rgba(103,232,249,0.45)]'
              : 'glass-chip text-[#A7A3C7] hover:text-[#E6EDF7]'
          }`}
        >
          {tab}
        </button>
      ))}
    </div>
  );

  const viewToggle = (
    <div className="flex items-center gap-4 font-mono text-xs tracking-widest">
      {(['reel', 'grid'] as const).map((v) => (
        <button
          key={v}
          onClick={() => setView(v)}
          className={`uppercase cursor-pointer transition-colors ${view === v ? 'text-[#E6EDF7]' : 'text-[#A7A3C7]/50 hover:text-[#E6EDF7]'}`}
        >
          {v}
        </button>
      ))}
    </div>
  );

  const preview = (proj: Project, cls = '') => (
    <div className={`relative w-full h-full rounded-xl overflow-hidden bg-gradient-to-br ${proj.previewGradient} flex items-center justify-center p-[8%] ${cls}`}>
      <div className="w-full h-full max-w-[420px]">{renderIllustration(proj.illustrationSvg, proj.verticalColor)}</div>
      <span className="absolute bottom-3 right-3 px-2 py-0.5 rounded font-mono text-[9px] font-black glass-chip">{proj.badge}</span>
    </div>
  );

  return (
    <section
      id="projects"
      ref={sectionRef}
      className="relative w-full"
      style={view === 'reel' ? { height: `${((n + 0.5) * 1.5 + 1) * 100}vh` } : undefined}
      aria-label="Projects Section"
      data-cursor="view"
    >
      {view === 'reel' ? (
        <div className="sticky top-0 h-screen w-full overflow-hidden select-none">
          {/* Colour grade: the whole stage tints toward the active project's colour */}
          {projects.map((proj, i) => (
            <div
              key={`tint-${proj.id}`}
              className="absolute inset-0 pointer-events-none"
              style={{
                opacity: clamp(1 - Math.abs(pos - i - 0.2) * 1.0) * 0.9,
                background: `radial-gradient(ellipse 70% 60% at ${i % 2 === 0 ? 68 : 32}% 48%, rgb(${hexToRgb(proj.verticalColor)} / 0.38) 0%, rgb(${hexToRgb(proj.verticalColor)} / 0.1) 45%, transparent 75%)`,
              }}
            />
          ))}
          <div className="absolute inset-0 pointer-events-none" style={{ background: 'radial-gradient(ellipse at center, transparent 40%, rgba(5,4,14,0.55) 100%)' }} />

          {/* Pinned builder hanging from the crane: stays put while the projects scroll past */}
          <HangingMascot color={pos < -0.45 ? '#7F77DD' : projects[activeIdx]?.verticalColor ?? '#7F77DD'} kick={activeIdx} />

          {/* Intro statement with drifting project tiles */}
          <div className="absolute inset-0" style={{ opacity: clamp(1 - introD * 1.2), pointerEvents: 'none' }}>
            {projects.slice(0, 5).map((proj, i) => {
              const spots = [
                { l: '22%', t: '16%', w: 190 },
                { l: '40%', t: '58%', w: 120 },
                { l: '66%', t: '30%', w: 150 },
                { l: '72%', t: '66%', w: 230 },
                { l: '10%', t: '64%', w: 140 },
              ][i];
              return (
                <div
                  key={proj.id}
                  className="absolute glass rounded-lg p-1.5 hidden sm:block"
                  style={{
                    left: spots.l,
                    top: spots.t,
                    width: spots.w,
                    aspectRatio: '4 / 3',
                    transform: `translateY(${-introD * (80 + i * 50)}px) rotate(${(i - 2) * 2.5}deg)`,
                    ...glowStyle(proj.verticalColor),
                  }}
                >
                  {preview(proj)}
                </div>
              );
            })}
            <div className="absolute left-[8%] sm:left-[6%] top-[26%] max-w-[560px] sm:max-w-[36vw] pr-6" style={{ transform: `translateY(${-introD * 60}px)` }}>
              <p className="text-[#E6EDF7] text-4xl sm:text-6xl leading-[1.05]" style={{ ...SERIF, textShadow: '0 0 40px rgba(139,92,246,0.55)' }}>
                We don&apos;t build what it looks like, we build what it <em>does</em>.
              </p>
              <p className="mt-6 font-mono text-xs tracking-widest text-[#A7A3C7] uppercase">Scroll to explore the work</p>
            </div>
          </div>

          {/* Project slides (masked so they fade out before touching the header) */}
          <div
            className="absolute inset-0"
            style={{
              WebkitMaskImage: 'linear-gradient(to bottom, transparent 0%, transparent 12%, #000 20%, #000 88%, transparent 100%)',
              maskImage: 'linear-gradient(to bottom, transparent 0%, transparent 12%, #000 20%, #000 88%, transparent 100%)',
            }}
          >
          {projects.map((proj, i) => {
            const d = i - pos;
            if (d > 0.55 || d < -1.1) return null;
            const right = i % 2 === 0; // even projects: image right, description left; odd: mirrored
            const ratio = RATIOS[i % RATIOS.length];
            const { first, rest } = splitTitle(proj.title);
            const active = d < 0.05 && d > -0.5;

            // Timeline (d = distance still to scroll until this project is centred):
            //  0.5..0.38  faint small teaser fades in (on the side of the previous description)
            //  0.3..0     teaser grows in place into the featured image
            //  0..-0.6    featured, description dwells
            // -0.6..-1.0  shrinks, drifts up, fades while the next teaser grows
            let scale = 1, opacity = 1, y = 0;
            if (d > 0.3) {
              const t = clamp((0.5 - d) / 0.12);
              scale = 0.34; opacity = 0.5 * smooth(t); y = 7;
            } else if (d > 0) {
              const t = smooth(1 - d / 0.3);
              scale = 0.34 + 0.66 * t; opacity = 0.5 + 0.5 * t; y = 7 * (d / 0.3);
            } else if (d < -0.6) {
              const u = clamp((-d - 0.6) / 0.4);
              scale = 1 - 0.22 * u; opacity = clamp(1 - u * 1.3); y = -u * 16;
            }
            if (!isDesktop && d > 0.3) opacity = 0; // no teaser on phones
            const labelOpacity = clamp(1 - d * 6) * clamp(1 - (-d - 0.5) * 6);
            const cx = isDesktop ? (right ? 72 : 28) : 50;
            const widthVw = isDesktop ? (ratio < 1 ? 27 : ratio > 1.2 ? 34 : 29) : ratio < 1 ? 66 : 86;
            // narrow windows: the image may never be taller than ~30% of the window, so it always
            // stays clear of the description card pinned below it
            const widthCss = isDesktop ? `${widthVw}vw` : `min(${widthVw}vw, ${(ratio * 30).toFixed(1)}vh)`;
            const maxPx = ratio < 1 ? 430 : 600;

            return (
              <div key={proj.id}>
                <div
                  className="absolute top-1/2"
                  style={{
                    left: `${cx}%`,
                    ...(isDesktop ? {} : { top: '22vh' }),
                    width: widthCss,
                    maxWidth: maxPx,
                    opacity,
                    transform: isDesktop
                      ? `translate3d(-50%, calc(-46% + ${y}vh), 0) scale(${scale})`
                      : `translate3d(-50%, ${y}vh, 0) scale(${scale})`,
                    pointerEvents: active ? 'auto' : 'none',
                  }}
                >
                  <div className="text-center mb-3" style={{ opacity: labelOpacity }}>
                    <h3 className="text-[#E6EDF7] text-2xl sm:text-4xl leading-none">
                      <span className="italic" style={SERIF}>{first}</span>{' '}
                      <span className="font-display font-medium">{rest}</span>
                    </h3>
                    <div className="mt-1.5 font-mono text-xs tracking-[0.25em] uppercase" style={{ color: proj.verticalColor }}>
                      {proj.vertical}
                    </div>
                  </div>
                  <button
                    onClick={() => setSelectedProject(proj)}
                    className="group block w-full glass rounded-2xl p-2 cursor-pointer text-left"
                    style={{ aspectRatio: String(ratio), ...glowStyle(proj.verticalColor) }}
                    aria-label={`Open ${proj.title}`}
                  >
                    {preview(proj, 'transition-transform duration-700 group-hover:scale-[1.02]')}
                  </button>
                </div>

                <DescPanel proj={proj} index={i} d={d} right={right} isDesktop={isDesktop} onOpen={() => setSelectedProject(proj)} />
              </div>
            );
          })}
          </div>

          {/* Header: title + filters */}
          <div className="absolute top-20 sm:top-24 left-4 sm:left-8 right-4 sm:right-8 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
            <h2 className="font-display font-black text-xl sm:text-2xl text-[#E6EDF7] tracking-tight">Things we built</h2>
            <div className="pointer-events-auto">{filters}</div>
          </div>

          {/* Bottom bar: label / toggle / progress */}
          <div className="absolute bottom-6 left-4 sm:left-8 right-4 sm:right-8 flex items-center justify-between font-mono text-xs tracking-widest text-[#A7A3C7]">
            <span className="hidden sm:inline uppercase">{String(activeIdx + 1).padStart(2, '0')} / {String(n).padStart(2, '0')}</span>
            {viewToggle}
            <span className="flex items-center gap-2 uppercase">
              scroll
              <span className="inline-block w-16 h-px bg-white/20 relative overflow-hidden">
                <span className="absolute inset-y-0 left-0 bg-[#67E8F9]" style={{ width: `${p * 100}%` }} />
              </span>
              {Math.round(p * 100)}%
            </span>
          </div>
        </div>
      ) : (
        /* GRID view: every project at a glance */
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-28">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-10">
            <h2 className="font-display font-black text-4xl sm:text-6xl text-[#E6EDF7] tracking-tight">Things we built</h2>
            <div className="flex flex-col items-end gap-3">
              {viewToggle}
              {filters}
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((proj) => {
              const { first, rest } = splitTitle(proj.title);
              return (
                <button
                  key={proj.id}
                  onClick={() => setSelectedProject(proj)}
                  className="group glass rounded-2xl p-3 text-left cursor-pointer hover:-translate-y-1"
                  style={glowStyle(proj.verticalColor)}
                >
                  <div className="aspect-[4/3]">{preview(proj, 'transition-transform duration-700 group-hover:scale-[1.02]')}</div>
                  <div className="mt-3 px-1 pb-1">
                    <div className="text-xl text-[#E6EDF7]">
                      <span className="italic" style={SERIF}>{first}</span> <span className="font-display font-medium">{rest}</span>
                    </div>
                    <div className="mt-1 font-mono text-[10px] tracking-[0.2em] uppercase" style={{ color: proj.verticalColor }}>{proj.vertical}</div>
                    <p className="mt-2 text-xs text-[#A7A3C7] line-clamp-2">{proj.descriptionLines[0]}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Project Detail Modal on Click */}
      {selectedProject && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md"
          onClick={() => setSelectedProject(null)}
        >
          <div
            className="relative max-w-2xl w-full rounded-2xl glass glass-flat glow-violet p-6 sm:p-8 text-[#E6EDF7] max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedProject(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-[#E6EDF7] cursor-pointer"
              aria-label="Close project modal"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 mb-2">
              <span
                className="px-3 py-1 rounded text-xs font-mono font-bold uppercase text-white"
                style={{ backgroundColor: selectedProject.verticalColor }}
              >
                {selectedProject.vertical}
              </span>
              <span className="font-mono text-xs text-[#A7A3C7]">
                {selectedProject.badge}
              </span>
            </div>

            <h3 className="font-display font-black text-2xl sm:text-3xl text-white">
              {selectedProject.title}
            </h3>

            {/* Illustration preview inside modal */}
            <div
              className={`w-full h-44 rounded-xl bg-gradient-to-br ${selectedProject.previewGradient} flex items-center justify-center p-4 my-5 border border-white/10`}
            >
              {renderIllustration(selectedProject.illustrationSvg, selectedProject.verticalColor)}
            </div>

            {/* What we learned */}
            <div className="space-y-4">
              <div>
                <h4 className="font-mono text-xs font-bold uppercase text-[#67E8F9] tracking-wider mb-2">
                  What we learned along the way:
                </h4>
                <ul className="space-y-1.5 text-xs sm:text-sm text-[#A7A3C7]">
                  {selectedProject.learnedTakeaways.map((point, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <Sparkles className="w-3.5 h-3.5 text-[#67E8F9] mt-0.5 shrink-0" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Team */}
              <div>
                <h4 className="font-mono text-xs font-bold uppercase text-white tracking-wider mb-1">
                  Built by the squad:
                </h4>
                <p className="font-mono text-xs text-[#A7A3C7]">
                  {selectedProject.builtBy.join(' · ')}
                </p>
              </div>

              {/* GitHub Link */}
              <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                <a
                  href={selectedProject.githubUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-white/10 hover:bg-white/20 text-[#E6EDF7] font-mono text-xs font-bold transition-colors cursor-pointer"
                >
                  <Github className="w-4 h-4" />
                  <span>Inspect GitHub Repo</span>
                </a>
                <button
                  onClick={() => setSelectedProject(null)}
                  className="font-mono text-xs text-[#A7A3C7] hover:text-white"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </section>
  );
}
