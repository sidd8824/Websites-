import { useEffect, useId, useRef, type ReactNode } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { VB_H, VB_W, buildCloth, peakY } from './clothMath';
import { ROBOT_H, ROBOT_HAND_Y, ROBOT_SVG, ROBOT_W, poseRobot } from './robotMarkup';

gsap.registerPlugin(ScrollTrigger);

// ONE bright colour moment on the page. Scrolling toward the wrapped section, a violet cloth
// is hauled up the screen by a little robot that holds its middle and marches upward. The
// cloth drapes down on both sides and ripples as you scroll, and in the end it covers the
// whole viewport. Everything is driven by the scrollbar: scroll back and the robot walks
// back down, pulling the cloth with it. After the section, the panel simply fades into the page background. There are no timed or automatic colour fades.

interface Props {
  children: ReactNode;
  from: string; // cloth colour (top) / panel body gradient start
  to: string; // panel body gradient end / exit edge colour
  back: string; // lighter cloth lining visible behind the front cloth
  mid: string; // unused accent kept for API compatibility
  accent: string; // glow that follows the mouse inside the panel
}

const IN_VH = 70; // height of the entrance runway, in vh
const OUT_VH = 24; // height of the soft fade-out under the panel, in vh

export default function ColorPanel({ children, from, to, back, accent }: Props) {
  const uid = useId().replace(/:/g, '');
  const wrapRef = useRef<HTMLDivElement>(null);
  const clothSvgRef = useRef<SVGSVGElement>(null);
  const liningRef = useRef<SVGPathElement>(null);
  const frontRef = useRef<SVGPathElement>(null);
  const clipRef = useRef<SVGPathElement>(null);
  const edgeRef = useRef<SVGPathElement>(null);
  const foldRefs = useRef<(SVGPolygonElement | null)[]>([]);
  const robotRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const wrap = wrapRef.current;
    const svg = clothSvgRef.current;
    const robot = robotRef.current;
    if (!wrap || !svg || !robot) return;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const update = (p: number, scrollY: number) => {
      const phase = scrollY * 0.022; // walk cycle follows the distance scrolled
      const front = buildCloth(p, phase, 2.4, 0);
      const lining = buildCloth(p, phase + 1.7, 3.4, -4.5);
      frontRef.current?.setAttribute('d', front.fill);
      clipRef.current?.setAttribute('d', front.fill);
      liningRef.current?.setAttribute('d', lining.fill);
      edgeRef.current?.setAttribute('d', front.edge);
      front.folds.forEach((f, i) => foldRefs.current[i]?.setAttribute('points', f.points));

      // robot: hands sit on the held point of the cloth
      const hPx = svg.clientHeight;
      const w = Math.min(150, Math.max(92, window.innerWidth * 0.11));
      const k = w / ROBOT_W;
      const peakPx = (peakY(p) / VB_H) * hPx;
      robot.style.width = `${w}px`;
      robot.style.height = `${ROBOT_H * k}px`;
      robot.style.transform = `translate(-50%, ${(peakPx - ROBOT_HAND_Y * k - 2).toFixed(1)}px)`;
      poseRobot(robot, phase);
    };

    if (reduce) {
      update(1, 0);
      robot.style.display = 'none';
      return;
    }

    update(0, window.scrollY);
    const enter = ScrollTrigger.create({
      trigger: wrap,
      start: 'top bottom',
      end: 'top top',
      onUpdate: (self) => update(self.progress, window.scrollY),
      onRefresh: (self) => update(self.progress, window.scrollY),
    });
    return () => {
      enter.kill();
    };
  }, []);

  const layer = 'absolute left-0 w-full pointer-events-none';

  return (
    <div
      ref={wrapRef}
      className="relative w-full"
      style={{ isolation: 'isolate', paddingTop: `${IN_VH}vh`, paddingBottom: `${OUT_VH}vh` }}
    >
      {/* The cloth: lining, front, fold shading and a lit edge */}
      <svg
        ref={clothSvgRef}
        className={layer}
        style={{ top: 0, height: `${IN_VH}vh`, zIndex: -1, overflow: 'visible' }}
        viewBox={`0 0 ${VB_W} ${VB_H}`}
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <defs>
          <clipPath id={`cloth-${uid}`}>
            <path ref={clipRef} />
          </clipPath>
          <linearGradient id={`fade-${uid}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#fff" />
            <stop offset="0.45" stopColor="#fff" />
            <stop offset="1" stopColor="#000" />
          </linearGradient>
          <mask id={`mask-${uid}`}>
            <rect x="-40" y="-200" width={VB_W + 80} height={VB_H + 200} fill={`url(#fade-${uid})`} />
          </mask>
        </defs>
        <path ref={liningRef} fill={back} />
        <path ref={frontRef} fill={from} />
        <g clipPath={`url(#cloth-${uid})`} mask={`url(#mask-${uid})`}>
          {Array.from({ length: 16 }, (_, i) => (
            <polygon
              key={i}
              ref={(el) => { foldRefs.current[i] = el; }}
              fill={i % 2 === 0 ? 'rgba(12,0,48,0.26)' : 'rgba(255,255,255,0.10)'}
            />
          ))}
        </g>
        <path ref={edgeRef} fill="none" stroke="#DDD6FE" strokeOpacity="0.85" strokeWidth="2.5" vectorEffect="non-scaling-stroke" />
      </svg>

      {/* The hauler robot, pinned to the held point of the cloth */}
      <div
        ref={robotRef}
        className="absolute pointer-events-none"
        style={{ left: '50%', top: 0, zIndex: 0, willChange: 'transform' }}
        aria-hidden="true"
        dangerouslySetInnerHTML={{ __html: ROBOT_SVG }}
      />

      {/* Panel body */}
      <div
        className="absolute left-0 w-full pointer-events-none"
        style={{
          zIndex: -2,
          top: `${IN_VH - 1}vh`,
          bottom: 0,
          WebkitMaskImage: `linear-gradient(to bottom, #000 calc(100% - ${OUT_VH}vh), transparent 100%)`,
          maskImage: `linear-gradient(to bottom, #000 calc(100% - ${OUT_VH}vh), transparent 100%)`,
          background: `
            radial-gradient(circle 340px at var(--mx, -500px) var(--my, -500px), ${accent}59 0%, transparent 70%) fixed,
            radial-gradient(rgba(255,255,255,0.10) 2px, transparent 2.5px) 0 0 / 30px 30px,
            linear-gradient(180deg, ${from} 0%, ${to} 100%)`,
        }}
        aria-hidden="true"
      />

      {children}
    </div>
  );
}
